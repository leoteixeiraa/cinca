<?php

include_once('conexao.php');

$postjson = json_decode(file_get_contents('php://input'), true);


//LISTAGEM DAS PESSOAS FISICA E PESQUISA PELO NOME E EMAIL

if($postjson['requisicao'] == 'listar'){

 if($postjson['textoBuscar'] == ''){
  $query = mysqli_query($mysqli, "select * from pessoaFisica order by idPFisica asc");
}else{
  $busca = $postjson['textoBuscar'] . '%';
  $query = mysqli_query($mysqli, "select * from pessoaFisica where nome LIKE '$busca' or cpf LIKE '$busca' order by idPFisica desc ");
}

while($row = mysqli_fetch_array($query)){ 
  $dados2[] = array(
    'nome' => $row['nome'],
    'cpf' => $row['cpf'],
    'rg' => $row['rg'],
    'sexo' => $row['sexo'], 
    'estadoCivil' => $row['estadoCivil'],
    'cep' => $row['cep'],
    'endereco' => $row['endereco'],
    'complemento' => $row['complemento'],
    'cidade' => $row['cidade'],
    'bairro' => $row['bairro'],
    'uf' => $row['uf'],
    'telefone' => $row['telefone'],
    'email' => $row['email']
  );

}

if($query){
  $result = json_encode(array('success'=>true, 'result'=>$dados2));

}else{
  $result = json_encode(array('success'=>false));

}
echo $result;

}else if($postjson['requisicao'] == 'add'){

 $query = mysqli_query($mysqli, "INSERT INTO pessoaFisica SET nome = '$postjson[nome]', cpf = '$postjson[cpf]', rg = '$postjson[rg]', sexo = '$postjson[sexo]', dataNascimento = '$postjson[dataNascimento]', estadoCivil = '$postjson[estadoCivil]', cep = '$postjson[cep]', endereco = '$postjson[endereco]', complemento = '$postjson[complemento]', cidade = '$postjson[cidade]', bairro = '$postjson[bairro]', uf = '$postjson[uf]', telefone = '$postjson[telefone]', email = '$postjson[email]' ");
 
 $idPFisica = mysqli_insert_id($mysqli);
 

 if($query){
  $result = json_encode(array('success'=>true, 'idPFisica'=>$idPFisica));

}else{
  $result = json_encode(array('success'=>false));

}
echo $result;

}else if($postjson['requisicao'] == 'editar'){

 $query = mysqli_query($mysqli, "UPDATE pessoaFisica SET nome = '$postjson[nome]', cpf = '$postjson[cpf]', rg = '$postjson[rg]', sexo = '$postjson[sexo]', dataNascimento = '$postjson[dataNascimento]', estadoCivil = '$postjson[estadoCivil]', cep = '$postjson[cep]', endereco = '$postjson[endereco]', complemento = '$postjson[complemento]', cidade = '$postjson[cidade]', bairro = '$postjson[bairro]', uf = '$postjson[uf]', telefone = '$postjson[telefone]' WHERE idPFisica = '$postjson[idPFisica]' ");

 $idPFisica = mysqli_insert_id($mysqli);
 

 if($query){
  $result = json_encode(array('success'=>true, 'idPFisica'=>$idPFisica));

}else{
  $result = json_encode(array('success'=>false));

}
echo $result;

}else if($postjson['requisicao'] == 'excluir'){

 $query = mysqli_query($mysqli, "delete from pessoaFisica where idPFisica = '$postjson[idPFisica]' ");

 $idPFisica = mysqli_insert_id($mysqli);
 

 if($query){
  $result = json_encode(array('success'=>true, 'idPFisica'=>$idPFisica));

}else{
  $result = json_encode(array('success'=>false));

}
echo $result;

}




